import turtle  # Import turtle module
import os     # Import os module

wn = turtle.Screen()  # Create a screen
wn.title("Pong")      # Change title to Pong
wn.bgcolor("purple")  # Change background color to purple
wn.setup(width=800, height=600)   # Change screen size to 800x600
wn.tracer(0)       # Turns off the screen updates

# Score
score_a = 0       # Change score to 0 for player A
score_b = 0       # Change score to 0 for player B

# Paddle A
paddle_a = turtle.Turtle() # Create a turtle object called paddle_a
paddle_a.speed(0)        # Set the speed to maximum 
paddle_a.shape("square") # Change shape to square 
paddle_a.color("white")  # Change color to white 
paddle_a.shapesize(stretch_wid=5,stretch_len=1) # Change size to 5x1
paddle_a.penup()     # Pen up so it doesn't draw a line
paddle_a.goto(-350, 0) # Start at (-350, 0)

# Paddle B
paddle_b = turtle.Turtle()  # Create a turtle object called paddle_b
paddle_b.speed(0)     # Set the speed to maximum 
paddle_b.shape("square") # Change shape to square
paddle_b.color("white") # Change color to white 
paddle_b.shapesize(stretch_wid=5,stretch_len=1) # Change size to 5x1
paddle_b.penup()    # Pen up so it doesn't draw a line
paddle_b.goto(350, 0)  # Start at (350, 0)

# Ball
ball = turtle.Turtle() # Create a turtle object called ball
ball.speed(0)   # Set the speed to maximum
ball.shape("circle")  # Change shape to circle
ball.color("yellow")  # Change color to yellow
ball.penup()  # Pen up so it doesn't draw a line
ball.goto(0, 0)  # Start at (0, 0)
ball.dx = 0.2  # Increase speed
ball.dy = 0.2  # Increase speed

# Pen
pen = turtle.Turtle() # Create a turtle object called pen 
pen.speed(0)  # Set the speed to maximum
pen.shape("circle") # Change shape to circle
pen.color("cyan")  # Change color to cyan
pen.penup()     # Pen up so it doesn't draw a line
pen.hideturtle() # Hide the turtle
pen.goto(0, 260)  # Start at (0, 260)
pen.write("Player A: 0  Player B: 0", align="center", font=("Comic Sans MS", 24, "normal"))  # Change font to Comic Sans MS

# Functions
def paddle_a_up():     # Create a function called paddle_a_up
    y = paddle_a.ycor() # Set y to the y coordinate of paddle_a
    y += 20             # Add 20 to y
    paddle_a.sety(y)    # Set the y coordinate of paddle_a to y

def paddle_a_down():
    y = paddle_a.ycor()
    y -= 20
    paddle_a.sety(y)

def paddle_b_up():
    y = paddle_b.ycor()
    y += 20
    paddle_b.sety(y)

def paddle_b_down():
    y = paddle_b.ycor()
    y -= 20
    paddle_b.sety(y)

# Keyboard bindings
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

# Main game loop
while True:
    wn.update() # Update the screen
    
    # Move the ball
    ball.setx(ball.xcor() + ball.dx) # Add ball.dx to the x coordinate of ball
    ball.sety(ball.ycor() + ball.dy) # Add ball.dy to the y coordinate of ball

    # Border checking

    # Top and bottom
    if ball.ycor() > 290:  # If ball is at the top
        ball.sety(290)   # Set y coordinate of ball to 290
        ball.dy *= -1   # Reverse the direction of ball.dy
        os.system("afplay bounce.wav&")     # Play bounce.wav
    
    elif ball.ycor() < -290:  
        ball.sety(-290)       
        ball.dy *= -1
        os.system("afplay bounce.wav&")

    # Left and right
    if ball.xcor() > 350:  # If ball is at the right
        score_a += 1      # Add 1 to score_a
        pen.clear()     # Clear the screen
        pen.write("Player A: {}  Player B: {}".format(score_a, score_b), align="center", font=("Comic Sans MS", 24, "normal"))  # Change font to Comic Sans MS
        ball.goto(0, 0)  # Start at (0, 0)
        ball.dx *= -1    # Reverse the direction of ball.dx

    elif ball.xcor() < -350:
        score_b += 1
        pen.clear()
        pen.write("Player A: {}  Player B: {}".format(score_a, score_b), align="center", font=("Comic Sans MS", 24, "normal"))  # Change font to Comic Sans MS
        ball.goto(0, 0)
        ball.dx *= -1

    # Paddle and ball collisions
    if ball.xcor() < -340 and ball.ycor() < paddle_a.ycor() + 50 and ball.ycor() > paddle_a.ycor() - 50:  # If ball is at the left and between the top and bottom of paddle_a
        ball.dx *= -1   # Reverse the direction of ball.dx
        os.system("afplay bounce.wav&")   # Play bounce.wav
    
    elif ball.xcor() > 340 and ball.ycor() < paddle_b.ycor() + 50 and ball.ycor() > paddle_b.ycor() - 50:
        ball.dx *= -1
        os.system("afplay bounce.wav&")  # Play bounce.wav